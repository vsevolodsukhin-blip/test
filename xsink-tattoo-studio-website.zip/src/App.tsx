import CustomCursor from "./components/CustomCursor";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import About from "./components/About";
import Gallery from "./components/Gallery";
import Artists from "./components/Artists";
import Process from "./components/Process";
import Services from "./components/Services";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import { ApplicationsProvider } from "./store/applications";
import { motion, useScroll, useSpring } from "framer-motion";

function App() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });

  return (
    <ApplicationsProvider>
      <div className="relative bg-dark min-h-screen">
        {/* Custom Cursor */}
        <CustomCursor />

        {/* Noise overlay */}
        <div className="noise-overlay" />

        {/* Progress bar */}
        <motion.div
          className="fixed top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-accent/80 via-accent to-accent/80 origin-left z-[200]"
          style={{ scaleX }}
        />

        {/* Navbar */}
        <Navbar />

        {/* Main content */}
        <main>
          <Hero />
          <Marquee />
          <About />
          <Gallery />
          <Marquee />
          <Artists />
          <Process />
          <Services />
          <Contact />
        </main>

        {/* Footer */}
        <Footer />
      </div>
    </ApplicationsProvider>
  );
}

export default App;
