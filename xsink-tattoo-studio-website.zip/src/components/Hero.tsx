import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.1]);

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image with parallax */}
      <motion.div className="absolute inset-0 z-0" style={{ y, scale }}>
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url(https://images.pexels.com/photos/35742622/pexels-photo-35742622.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=2000)`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark/70 via-dark/50 to-dark" />
        <div className="absolute inset-0 bg-gradient-to-r from-dark/60 to-transparent" />
      </motion.div>

      {/* Liquid blobs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-accent/5 liquid-blob blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-[500px] h-[500px] bg-accent/3 liquid-blob-2 blur-3xl" />

      {/* Content */}
      <motion.div className="relative z-10 text-center px-6 max-w-5xl" style={{ opacity }}>
        {/* Top tag */}
        <motion.div
          className="inline-flex items-center gap-3 mb-8"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <span className="h-px w-12 bg-accent/50" />
          <span className="text-accent text-xs font-inter tracking-[0.3em] uppercase font-medium">
            Тату-студия в Москве
          </span>
          <span className="h-px w-12 bg-accent/50" />
        </motion.div>

        {/* Main title */}
        <motion.h1
          className="font-bebas text-[clamp(4rem,15vw,12rem)] leading-[0.85] tracking-wider mb-6"
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="text-gradient">XS</span>
          <span className="text-white">Ink</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          className="font-playfair text-xl md:text-2xl text-white/60 italic max-w-xl mx-auto mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
        >
          Искусство на коже. Каждая работа — уникальная история, рассказанная через чернила.
        </motion.p>

        {/* CTA buttons */}
        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
        >
          <a
            href="#contact"
            className="glass-btn px-10 py-4 text-accent font-inter font-medium tracking-widest uppercase text-sm cursor-hover"
          >
            <span className="relative z-10">Записаться на сеанс</span>
          </a>
          <a
            href="#gallery"
            className="px-10 py-4 text-white/60 hover:text-white font-inter font-light tracking-widest uppercase text-sm transition-colors cursor-hover"
          >
            Смотреть работы →
          </a>
        </motion.div>

        {/* Stats */}
        <motion.div
          className="flex items-center justify-center gap-8 md:gap-16 mt-20"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
        >
          {[
            { number: "8+", label: "лет опыта" },
            { number: "3000+", label: "работ" },
            { number: "5", label: "мастеров" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="font-bebas text-3xl md:text-4xl text-gradient">{stat.number}</div>
              <div className="text-xs text-white/40 font-inter tracking-widest uppercase mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
      >
        <span className="text-[10px] font-inter tracking-[0.3em] uppercase text-white/30">Scroll</span>
        <motion.div
          className="w-[1px] h-8 bg-gradient-to-b from-accent/50 to-transparent"
          animate={{ scaleY: [1, 0.5, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        />
      </motion.div>
    </section>
  );
}
