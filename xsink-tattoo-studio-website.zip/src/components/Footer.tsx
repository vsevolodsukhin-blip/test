import AdminPanel from "./AdminPanel";

export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 bg-dark-light/30">
      {/* Top section */}
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <span className="font-bebas text-5xl tracking-wider text-gradient">XSInk</span>
            <p className="text-white/30 font-inter font-light mt-4 max-w-sm leading-relaxed">
              Тату-студия в самом сердце Москвы. Создаём уникальные произведения искусства на коже с 2016 года.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-xs font-inter tracking-[0.2em] uppercase text-white/50 mb-4">Навигация</h4>
            <div className="flex flex-col gap-3">
              {["О нас", "Галерея", "Мастера", "Услуги", "Контакты"].map((link) => (
                <a
                  key={link}
                  href={`#${link === "О нас" ? "about" : link === "Галерея" ? "gallery" : link === "Мастера" ? "artists" : link === "Услуги" ? "services" : "contact"}`}
                  className="text-sm font-inter text-white/30 hover:text-accent transition-colors cursor-hover"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-xs font-inter tracking-[0.2em] uppercase text-white/50 mb-4">Социальные сети</h4>
            <div className="flex flex-col gap-3">
              {["Telegram", "Instagram", "VKontakte", "YouTube"].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="text-sm font-inter text-white/30 hover:text-accent transition-colors cursor-hover"
                >
                  {social}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom */}
      <div className="border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs font-inter text-white/20">
            © 2024 XSInk Studio. Все права защищены.
          </p>
          <div className="flex items-center gap-6">
            <p className="text-xs font-inter text-white/20">
              Сделано с ✦ любовью к искусству
            </p>
            <AdminPanel />
          </div>
        </div>
      </div>

      {/* Large watermark */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 pointer-events-none select-none overflow-hidden w-full text-center">
        <span className="font-bebas text-[15vw] leading-none text-white/[0.015] tracking-[0.1em]">
          XSINK
        </span>
      </div>
    </footer>
  );
}
