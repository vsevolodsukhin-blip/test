import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const artists = [
  {
    name: "Алекс Волков",
    role: "Основатель / Blackwork",
    image: "https://images.pexels.com/photos/38242206/pexels-photo-38242206.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=500",
    experience: "12 лет",
    works: "1200+",
  },
  {
    name: "Мария Тень",
    role: "Fine Line / Минимализм",
    image: "https://images.pexels.com/photos/4069785/pexels-photo-4069785.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=500",
    experience: "8 лет",
    works: "800+",
  },
  {
    name: "Дмитрий Кросс",
    role: "Реализм / Портреты",
    image: "https://images.pexels.com/photos/4117793/pexels-photo-4117793.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=500",
    experience: "10 лет",
    works: "950+",
  },
];

export default function Artists() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });

  return (
    <section id="artists" className="relative py-32 overflow-hidden">
      <div className="absolute top-1/3 right-0 w-[400px] h-[400px] bg-accent/[0.02] liquid-blob blur-3xl" />

      <div ref={ref} className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center justify-center gap-3 mb-6">
            <span className="h-px w-8 bg-accent/50" />
            <span className="text-accent text-xs font-inter tracking-[0.3em] uppercase font-medium">
              Команда
            </span>
            <span className="h-px w-8 bg-accent/50" />
          </div>
          <h2 className="font-bebas text-5xl md:text-8xl tracking-wider">
            Наши <span className="text-gradient">мастера</span>
          </h2>
        </motion.div>

        {/* Artists grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {artists.map((artist, i) => (
            <motion.div
              key={artist.name}
              className="glass-card group cursor-hover"
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: i * 0.15 }}
              whileHover={{ y: -8, transition: { duration: 0.3 } }}
            >
              {/* Image */}
              <div className="relative overflow-hidden rounded-t-[23px] aspect-[5/6]">
                <motion.img
                  src={artist.image}
                  alt={artist.name}
                  className="w-full h-full object-cover"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.6 }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-transparent to-transparent" />
                
                {/* Hover overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                  <div className="flex gap-4">
                    <div className="glass-card px-3 py-2 !rounded-xl">
                      <div className="text-xs text-white/50 font-inter">Опыт</div>
                      <div className="text-sm text-accent font-inter font-medium">{artist.experience}</div>
                    </div>
                    <div className="glass-card px-3 py-2 !rounded-xl">
                      <div className="text-xs text-white/50 font-inter">Работ</div>
                      <div className="text-sm text-accent font-inter font-medium">{artist.works}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Info */}
              <div className="p-6 relative z-10">
                <h3 className="font-bebas text-2xl tracking-wider text-white group-hover:text-gradient transition-all duration-300">
                  {artist.name}
                </h3>
                <p className="text-sm font-inter text-white/40 tracking-wide mt-1">
                  {artist.role}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
