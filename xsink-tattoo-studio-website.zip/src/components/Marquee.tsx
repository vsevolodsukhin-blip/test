// Marquee component

const words = [
  "BLACKWORK",
  "REALISM",
  "DOTWORK",
  "GEOMETRIC",
  "FINE LINE",
  "WATERCOLOR",
  "NEO-TRADITIONAL",
  "JAPANESE",
  "TRIBAL",
  "MINIMALISM",
];

export default function Marquee() {
  return (
    <div className="relative py-8 overflow-hidden border-y border-white/5 bg-dark-light/50">
      <div className="marquee-track flex whitespace-nowrap">
        {[...words, ...words].map((word, i) => (
          <span
            key={i}
            className="font-bebas text-5xl md:text-7xl text-white/[0.04] mx-6 md:mx-10 tracking-widest select-none"
          >
            {word}
            <span className="text-accent/20 mx-6">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
