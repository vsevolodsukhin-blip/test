import { motion } from "framer-motion";
import { useState, useEffect } from "react";

const navLinks = [
  { label: "О нас", href: "#about" },
  { label: "Галерея", href: "#gallery" },
  { label: "Мастера", href: "#artists" },
  { label: "Услуги", href: "#services" },
  { label: "Контакты", href: "#contact" },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <motion.nav
        className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 ${
          scrolled ? "glass-nav py-3" : "py-6"
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <motion.a
            href="#"
            className="flex items-center gap-2 cursor-hover"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="font-bebas text-4xl tracking-wider text-gradient">
              XSInk
            </span>
          </motion.a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link, i) => (
              <motion.a
                key={link.href}
                href={link.href}
                className="text-sm font-inter font-light text-white/60 hover:text-accent transition-colors duration-300 tracking-widest uppercase cursor-hover"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i + 0.3, duration: 0.5 }}
              >
                {link.label}
              </motion.a>
            ))}
            <motion.a
              href="#contact"
              className="glass-btn px-6 py-2.5 text-sm font-inter font-medium text-accent tracking-widest uppercase cursor-hover"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.5 }}
              whileTap={{ scale: 0.95 }}
            >
              Записаться
            </motion.a>
          </div>

          {/* Mobile menu button */}
          <motion.button
            className="md:hidden flex flex-col gap-1.5 w-8 cursor-hover z-[110]"
            onClick={() => setIsOpen(!isOpen)}
            whileTap={{ scale: 0.9 }}
          >
            <motion.span
              className="h-[2px] bg-white/80 block w-full origin-center"
              animate={isOpen ? { rotate: 45, y: 5 } : { rotate: 0, y: 0 }}
              transition={{ duration: 0.3 }}
            />
            <motion.span
              className="h-[2px] bg-white/80 block w-full"
              animate={isOpen ? { opacity: 0, x: -20 } : { opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            />
            <motion.span
              className="h-[2px] bg-white/80 block w-full origin-center"
              animate={isOpen ? { rotate: -45, y: -5 } : { rotate: 0, y: 0 }}
              transition={{ duration: 0.3 }}
            />
          </motion.button>
        </div>
      </motion.nav>

      {/* Mobile menu overlay */}
      <motion.div
        className="fixed inset-0 z-[99] bg-dark/95 backdrop-blur-xl flex flex-col items-center justify-center gap-8 md:hidden"
        initial={false}
        animate={isOpen ? { opacity: 1, pointerEvents: "auto" as const } : { opacity: 0, pointerEvents: "none" as const }}
        transition={{ duration: 0.4 }}
      >
        {navLinks.map((link, i) => (
          <motion.a
            key={link.href}
            href={link.href}
            className="font-bebas text-4xl text-white/80 hover:text-accent transition-colors tracking-widest cursor-hover"
            onClick={() => setIsOpen(false)}
            initial={{ opacity: 0, y: 30 }}
            animate={isOpen ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ delay: isOpen ? 0.1 * i + 0.2 : 0, duration: 0.4 }}
          >
            {link.label}
          </motion.a>
        ))}
      </motion.div>
    </>
  );
}
