import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useState } from "react";

const galleryImages = [
  {
    src: "https://images.pexels.com/photos/19312598/pexels-photo-19312598.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    title: "Детализация",
    style: "Fine Line",
    span: "row-span-2",
  },
  {
    src: "https://images.pexels.com/photos/3295586/pexels-photo-3295586.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=600",
    title: "Флора",
    style: "Watercolor",
    span: "",
  },
  {
    src: "https://images.pexels.com/photos/4117793/pexels-photo-4117793.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=600",
    title: "Процесс",
    style: "Blackwork",
    span: "",
  },
  {
    src: "https://images.pexels.com/photos/29616935/pexels-photo-29616935.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    title: "Геометрия тела",
    style: "Geometric",
    span: "row-span-2",
  },
  {
    src: "https://images.pexels.com/photos/7908899/pexels-photo-7908899.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=600",
    title: "В работе",
    style: "Realism",
    span: "",
  },
  {
    src: "https://images.pexels.com/photos/18476809/pexels-photo-18476809.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=600",
    title: "Мастерство",
    style: "Neo-Traditional",
    span: "",
  },
];

export default function Gallery() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section id="gallery" className="relative py-32 overflow-hidden">
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-accent/[0.02] liquid-blob-2 blur-3xl" />

      <div ref={ref} className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center justify-center gap-3 mb-6">
            <span className="h-px w-8 bg-accent/50" />
            <span className="text-accent text-xs font-inter tracking-[0.3em] uppercase font-medium">
              Портфолио
            </span>
            <span className="h-px w-8 bg-accent/50" />
          </div>
          <h2 className="font-bebas text-5xl md:text-8xl tracking-wider">
            Наши <span className="text-gradient">работы</span>
          </h2>
        </motion.div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 auto-rows-[250px]">
          {galleryImages.map((img, i) => (
            <motion.div
              key={i}
              className={`relative rounded-2xl overflow-hidden cursor-hover group ${img.span}`}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: i * 0.1 }}
              onHoverStart={() => setHoveredIndex(i)}
              onHoverEnd={() => setHoveredIndex(null)}
              whileHover={{ scale: 1.02 }}
            >
              <motion.img
                src={img.src}
                alt={img.title}
                className="w-full h-full object-cover"
                animate={{
                  scale: hoveredIndex === i ? 1.1 : 1,
                }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              />

              {/* Overlay */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-dark via-dark/20 to-transparent flex flex-col justify-end p-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: hoveredIndex === i ? 1 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <motion.span
                  className="text-accent text-xs font-inter tracking-[0.2em] uppercase mb-1"
                  initial={{ y: 20 }}
                  animate={{ y: hoveredIndex === i ? 0 : 20 }}
                  transition={{ duration: 0.4, delay: 0.1 }}
                >
                  {img.style}
                </motion.span>
                <motion.h3
                  className="font-bebas text-2xl tracking-wider text-white"
                  initial={{ y: 20 }}
                  animate={{ y: hoveredIndex === i ? 0 : 20 }}
                  transition={{ duration: 0.4 }}
                >
                  {img.title}
                </motion.h3>
              </motion.div>

              {/* Glass border on hover */}
              <motion.div
                className="absolute inset-0 rounded-2xl border border-accent/30"
                initial={{ opacity: 0 }}
                animate={{ opacity: hoveredIndex === i ? 1 : 0 }}
                transition={{ duration: 0.3 }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
