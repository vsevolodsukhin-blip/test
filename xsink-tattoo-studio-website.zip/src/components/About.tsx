import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

export default function About() {
  const [ref, inView] = useInView({ threshold: 0.2, triggerOnce: true });

  return (
    <section id="about" className="relative py-32 overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-accent/[0.02] liquid-blob blur-3xl" />

      <div ref={ref} className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Left - Image */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: -60 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="glass-card p-3">
              <div className="relative rounded-[20px] overflow-hidden aspect-[4/5]">
                <img
                  src="https://images.pexels.com/photos/28991646/pexels-photo-28991646.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700"
                  alt="XSInk Studio"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark/60 to-transparent" />
              </div>
            </div>
            {/* Floating badge */}
            <motion.div
              className="absolute -bottom-6 -right-6 glass-card px-6 py-4 flex items-center gap-3"
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <div className="w-3 h-3 rounded-full bg-green-400 glow-pulse" />
              <span className="text-sm font-inter text-white/80">Работаем сейчас</span>
            </motion.div>
          </motion.div>

          {/* Right - Text */}
          <motion.div
            initial={{ opacity: 0, x: 60 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="h-px w-8 bg-accent/50" />
              <span className="text-accent text-xs font-inter tracking-[0.3em] uppercase font-medium">
                О студии
              </span>
            </div>

            <h2 className="font-bebas text-5xl md:text-7xl tracking-wider mb-8">
              Где <span className="text-gradient">искусство</span>
              <br />
              встречает кожу
            </h2>

            <p className="text-white/50 font-inter font-light leading-relaxed mb-6 text-lg">
              XSInk — это пространство, где рождаются уникальные произведения тату-искусства. Наша студия объединяет
              талантливых мастеров, каждый из которых привносит свой неповторимый стиль и видение.
            </p>

            <p className="text-white/40 font-inter font-light leading-relaxed mb-10">
              Мы используем только премиальные пигменты и стерильное оборудование. 
              Каждый проект начинается с глубокого погружения в вашу идею — от эскиза до финального штриха.
            </p>

            {/* Features */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: "🎨", text: "Индивидуальный дизайн" },
                { icon: "🏆", text: "Премиум качество" },
                { icon: "🛡️", text: "100% стерильность" },
                { icon: "💎", text: "Уникальный стиль" },
              ].map((item, i) => (
                <motion.div
                  key={item.text}
                  className="glass-card p-4 flex items-center gap-3"
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.4 + i * 0.1 }}
                  whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
                >
                  <span className="text-xl">{item.icon}</span>
                  <span className="text-sm font-inter text-white/70">{item.text}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
