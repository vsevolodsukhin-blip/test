import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const services = [
  {
    icon: "✦",
    title: "Авторское тату",
    description: "Индивидуальный эскиз, созданный специально для вас. Полное погружение в вашу идею.",
    price: "от 5 000 ₽",
  },
  {
    icon: "◈",
    title: "Каверап",
    description: "Перекрытие старых или некачественных татуировок новым дизайном высокого уровня.",
    price: "от 7 000 ₽",
  },
  {
    icon: "◇",
    title: "Коррекция",
    description: "Обновление и доработка существующих татуировок для придания свежести и яркости.",
    price: "от 3 000 ₽",
  },
  {
    icon: "⬡",
    title: "Перманентный макияж",
    description: "Брови, стрелки, губы — подчеркните естественную красоту с помощью микропигментирования.",
    price: "от 8 000 ₽",
  },
  {
    icon: "⬢",
    title: "Консультация",
    description: "Бесплатная встреча с мастером для обсуждения идеи, размера, стиля и размещения.",
    price: "Бесплатно",
  },
  {
    icon: "◎",
    title: "Пирсинг",
    description: "Профессиональный пирсинг с использованием стерильного оборудования и гипоаллергенных украшений.",
    price: "от 2 000 ₽",
  },
];

export default function Services() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });

  return (
    <section id="services" className="relative py-32 overflow-hidden bg-dark-light/30">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-accent/[0.02] blur-3xl rounded-full" />

      <div ref={ref} className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center justify-center gap-3 mb-6">
            <span className="h-px w-8 bg-accent/50" />
            <span className="text-accent text-xs font-inter tracking-[0.3em] uppercase font-medium">
              Услуги
            </span>
            <span className="h-px w-8 bg-accent/50" />
          </div>
          <h2 className="font-bebas text-5xl md:text-8xl tracking-wider">
            Что мы <span className="text-gradient">предлагаем</span>
          </h2>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              className="glass-card p-8 group cursor-hover relative"
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: i * 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.3 } }}
            >
              {/* Icon */}
              <motion.div
                className="text-3xl text-accent mb-6 inline-block"
                whileHover={{ scale: 1.2, rotate: 90 }}
                transition={{ duration: 0.4 }}
              >
                {service.icon}
              </motion.div>

              <h3 className="font-bebas text-2xl tracking-wider text-white mb-3 group-hover:text-gradient transition-all">
                {service.title}
              </h3>

              <p className="text-sm font-inter text-white/40 leading-relaxed mb-6">
                {service.description}
              </p>

              {/* Price */}
              <div className="flex items-center justify-between">
                <span className="text-accent font-inter font-semibold text-lg">
                  {service.price}
                </span>
                <motion.span
                  className="text-white/20 group-hover:text-accent/60 transition-colors text-xl"
                  whileHover={{ x: 5 }}
                >
                  →
                </motion.span>
              </div>

              {/* Glow on hover */}
              <div className="absolute inset-0 rounded-[24px] bg-accent/[0.02] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
