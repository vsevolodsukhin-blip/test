import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const steps = [
  {
    number: "01",
    title: "Консультация",
    description: "Обсуждаем вашу идею, стиль, размер и расположение. Подбираем мастера под ваш запрос.",
  },
  {
    number: "02",
    title: "Эскиз",
    description: "Мастер создаёт уникальный дизайн на основе ваших пожеланий. Правки — до полного согласования.",
  },
  {
    number: "03",
    title: "Сеанс",
    description: "В комфортной атмосфере студии мастер воплощает эскиз на вашей коже. Стерильность гарантирована.",
  },
  {
    number: "04",
    title: "Уход",
    description: "Предоставляем подробную инструкцию по уходу и остаёмся на связи в период заживления.",
  },
];

export default function Process() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });

  return (
    <section className="relative py-32 overflow-hidden">
      <div ref={ref} className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center justify-center gap-3 mb-6">
            <span className="h-px w-8 bg-accent/50" />
            <span className="text-accent text-xs font-inter tracking-[0.3em] uppercase font-medium">
              Процесс
            </span>
            <span className="h-px w-8 bg-accent/50" />
          </div>
          <h2 className="font-bebas text-5xl md:text-8xl tracking-wider">
            Как мы <span className="text-gradient">работаем</span>
          </h2>
        </motion.div>

        {/* Steps */}
        <div className="relative">
          {/* Connection line */}
          <div className="absolute top-0 bottom-0 left-1/2 w-px bg-gradient-to-b from-transparent via-accent/20 to-transparent hidden lg:block" />

          <div className="space-y-16 lg:space-y-0 lg:grid lg:grid-cols-4 lg:gap-8">
            {steps.map((step, i) => (
              <motion.div
                key={step.number}
                className="relative"
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.7, delay: i * 0.15 }}
              >
                <div className="glass-card p-8 text-center group cursor-hover relative h-full">
                  {/* Number */}
                  <motion.div
                    className="font-bebas text-6xl text-gradient mb-4 relative z-10"
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.3 }}
                  >
                    {step.number}
                  </motion.div>

                  {/* Decorative dot */}
                  <div className="w-3 h-3 rounded-full bg-accent/30 mx-auto mb-6 relative z-10 glow-pulse" />

                  <h3 className="font-bebas text-2xl tracking-wider text-white mb-3 relative z-10">
                    {step.title}
                  </h3>

                  <p className="text-sm font-inter text-white/40 leading-relaxed relative z-10">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
