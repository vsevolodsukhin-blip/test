import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { useApplications } from "../store/applications";

const ADMIN_PASSWORD = "230914";

const styleLabels: Record<string, string> = {
  blackwork: "Blackwork",
  realism: "Реализм",
  fineline: "Fine Line",
  geometric: "Геометрия",
  watercolor: "Watercolor",
  other: "Другое",
};

export default function AdminPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [isAuth, setIsAuth] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const { applications, removeApplication } = useApplications();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuth(true);
      setError(false);
    } else {
      setError(true);
      setPassword("");
      setTimeout(() => setError(false), 2000);
    }
  };

  const handleClose = () => {
    setIsOpen(false);
    setIsAuth(false);
    setPassword("");
    setError(false);
    setConfirmDelete(null);
  };

  const handleDelete = (id: string) => {
    if (confirmDelete === id) {
      removeApplication(id);
      setConfirmDelete(null);
    } else {
      setConfirmDelete(id);
      setTimeout(() => setConfirmDelete(null), 3000);
    }
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <>
      {/* Trigger button — sits in footer */}
      <button
        onClick={() => setIsOpen(true)}
        className="text-[10px] font-inter text-white/10 hover:text-white/30 transition-colors duration-300 tracking-wider cursor-hover"
      >
        админ-панель
      </button>

      {/* Modal overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Backdrop */}
            <motion.div
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              onClick={handleClose}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />

            {/* Panel */}
            <motion.div
              className="relative w-full max-w-3xl max-h-[85vh] flex flex-col glass-card overflow-hidden"
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            >
              {!isAuth ? (
                /* ─── Login Screen ─── */
                <div className="p-8 md:p-12 flex flex-col items-center justify-center min-h-[350px] relative z-10">
                  <div className="w-16 h-16 rounded-full border border-accent/30 flex items-center justify-center mb-6">
                    <span className="text-2xl">🔒</span>
                  </div>

                  <h3 className="font-bebas text-3xl tracking-wider text-white mb-2">
                    Админ-панель
                  </h3>
                  <p className="text-sm font-inter text-white/30 mb-8">
                    Введите пароль для доступа
                  </p>

                  <form onSubmit={handleLogin} className="w-full max-w-xs space-y-4">
                    <div className="relative">
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Пароль"
                        autoFocus
                        className={`w-full bg-white/[0.04] border rounded-xl px-5 py-3.5 text-white font-inter text-sm text-center focus:outline-none transition-colors placeholder:text-white/20 tracking-[0.3em] ${
                          error
                            ? "border-red-500/50 bg-red-500/5"
                            : "border-white/10 focus:border-accent/40"
                        }`}
                      />
                      <AnimatePresence>
                        {error && (
                          <motion.p
                            className="text-red-400 text-xs font-inter text-center mt-2"
                            initial={{ opacity: 0, y: -5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0 }}
                          >
                            Неверный пароль
                          </motion.p>
                        )}
                      </AnimatePresence>
                    </div>

                    <motion.button
                      type="submit"
                      className="glass-btn w-full py-3.5 text-accent font-inter font-medium tracking-widest uppercase text-sm cursor-hover"
                      whileTap={{ scale: 0.97 }}
                    >
                      <span className="relative z-10">Войти</span>
                    </motion.button>
                  </form>

                  {/* Close */}
                  <button
                    onClick={handleClose}
                    className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/40 hover:text-white/80 transition-colors cursor-hover text-lg"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                /* ─── Applications Dashboard ─── */
                <>
                  {/* Header */}
                  <div className="flex items-center justify-between p-6 md:p-8 border-b border-white/5 shrink-0 relative z-10">
                    <div>
                      <h3 className="font-bebas text-2xl md:text-3xl tracking-wider text-white">
                        Заявки
                        <span className="ml-3 inline-flex items-center justify-center bg-accent/20 text-accent text-xs font-inter font-semibold rounded-full w-7 h-7 align-middle">
                          {applications.length}
                        </span>
                      </h3>
                      <p className="text-xs font-inter text-white/30 mt-1">
                        Обновляется в реальном времени
                      </p>
                    </div>

                    <button
                      onClick={handleClose}
                      className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/40 hover:text-white/80 transition-colors cursor-hover text-lg shrink-0"
                    >
                      ✕
                    </button>
                  </div>

                  {/* Applications list */}
                  <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-3 relative z-10 min-h-0">
                    <AnimatePresence mode="popLayout">
                      {applications.length === 0 ? (
                        <motion.div
                          className="text-center py-20"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          key="empty"
                        >
                          <div className="text-4xl mb-4 opacity-30">📭</div>
                          <p className="text-white/20 font-inter text-sm">Заявок пока нет</p>
                        </motion.div>
                      ) : (
                        applications.map((app) => (
                          <motion.div
                            key={app.id}
                            className="glass-card !rounded-xl p-5 relative group"
                            layout
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 20, scale: 0.95 }}
                            transition={{ duration: 0.3 }}
                          >
                            <div className="flex items-start justify-between gap-4 relative z-10">
                              <div className="flex-1 min-w-0">
                                {/* Name & phone */}
                                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mb-2">
                                  <h4 className="font-bebas text-xl tracking-wider text-white">
                                    {app.name}
                                  </h4>
                                  <a
                                    href={`tel:${app.phone}`}
                                    className="text-sm font-inter text-accent/80 hover:text-accent transition-colors cursor-hover"
                                  >
                                    {app.phone}
                                  </a>
                                </div>

                                {/* Style tag */}
                                {app.style && (
                                  <span className="inline-block text-[10px] font-inter tracking-widest uppercase bg-accent/10 text-accent/70 px-3 py-1 rounded-full mb-2">
                                    {styleLabels[app.style] || app.style}
                                  </span>
                                )}

                                {/* Message */}
                                {app.message && (
                                  <p className="text-sm font-inter text-white/40 leading-relaxed mt-1 break-words">
                                    {app.message}
                                  </p>
                                )}

                                {/* Date */}
                                <p className="text-[10px] font-inter text-white/15 mt-3 tracking-wider">
                                  {formatDate(app.createdAt)}
                                </p>
                              </div>

                              {/* Delete button */}
                              <motion.button
                                onClick={() => handleDelete(app.id)}
                                className={`shrink-0 px-4 py-2 rounded-xl text-xs font-inter font-medium tracking-wider uppercase transition-all duration-300 cursor-hover ${
                                  confirmDelete === app.id
                                    ? "bg-red-500/20 border border-red-500/40 text-red-400"
                                    : "bg-white/5 border border-white/10 text-white/30 hover:text-red-400 hover:border-red-400/30"
                                }`}
                                whileTap={{ scale: 0.95 }}
                              >
                                {confirmDelete === app.id ? "Точно?" : "Закрыть"}
                              </motion.button>
                            </div>
                          </motion.div>
                        ))
                      )}
                    </AnimatePresence>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
