import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useState } from "react";
import { useApplications } from "../store/applications";

export default function Contact() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });
  const { addApplication } = useApplications();
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    style: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addApplication({
      name: formData.name,
      phone: formData.phone,
      style: formData.style,
      message: formData.message,
    });
    setSubmitted(true);
    setFormData({ name: "", phone: "", style: "", message: "" });
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section id="contact" className="relative py-32 overflow-hidden">
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-accent/[0.02] liquid-blob blur-3xl" />
      <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-accent/[0.015] liquid-blob-2 blur-3xl" />

      <div ref={ref} className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="h-px w-8 bg-accent/50" />
              <span className="text-accent text-xs font-inter tracking-[0.3em] uppercase font-medium">
                Контакты
              </span>
            </div>

            <h2 className="font-bebas text-5xl md:text-7xl tracking-wider mb-8">
              Готовы к новой <span className="text-gradient">истории?</span>
            </h2>

            <p className="text-white/40 font-inter font-light leading-relaxed mb-12 text-lg max-w-lg">
              Запишитесь на бесплатную консультацию, и мы обсудим вашу идею. Каждый проект начинается с разговора.
            </p>

            {/* Contact Info */}
            <div className="space-y-6">
              {[
                { label: "Адрес", value: "Москва, ул. Тверская, 24, стр. 2", icon: "📍" },
                { label: "Телефон", value: "+7 (999) 123-45-67", icon: "📞" },
                { label: "Email", value: "hello@xsink.studio", icon: "✉️" },
                { label: "Время работы", value: "Пн-Сб: 11:00 — 21:00", icon: "🕐" },
              ].map((item, i) => (
                <motion.div
                  key={item.label}
                  className="flex items-center gap-4"
                  initial={{ opacity: 0, x: -20 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.3 + i * 0.1 }}
                >
                  <div className="glass-card w-12 h-12 flex items-center justify-center !rounded-xl text-lg shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <div className="text-xs font-inter text-white/30 tracking-widest uppercase mb-0.5">
                      {item.label}
                    </div>
                    <div className="text-sm font-inter text-white/70">{item.value}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Social links */}
            <motion.div
              className="flex gap-4 mt-10"
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.8 }}
            >
              {["Telegram", "Instagram", "VK"].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="glass-card px-5 py-2.5 !rounded-xl text-sm font-inter text-white/50 hover:text-accent transition-colors cursor-hover"
                >
                  {social}
                </a>
              ))}
            </motion.div>
          </motion.div>

          {/* Right - Form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="glass-card p-8 md:p-10">
              <h3 className="font-bebas text-3xl tracking-wider mb-8 relative z-10">
                Записаться на <span className="text-gradient">сеанс</span>
              </h3>

              {submitted ? (
                <motion.div
                  className="text-center py-16 relative z-10"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="text-5xl mb-4">✓</div>
                  <h4 className="font-bebas text-2xl text-gradient mb-2">Заявка отправлена!</h4>
                  <p className="text-white/40 font-inter text-sm">Мы свяжемся с вами в ближайшее время</p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5 relative z-10">
                  <div>
                    <label className="text-xs font-inter text-white/30 tracking-widest uppercase mb-2 block">
                      Ваше имя
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-5 py-3.5 text-white font-inter text-sm focus:outline-none focus:border-accent/40 transition-colors placeholder:text-white/20"
                      placeholder="Как вас зовут?"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-inter text-white/30 tracking-widest uppercase mb-2 block">
                      Телефон
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-5 py-3.5 text-white font-inter text-sm focus:outline-none focus:border-accent/40 transition-colors placeholder:text-white/20"
                      placeholder="+7 (___) ___-__-__"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-inter text-white/30 tracking-widest uppercase mb-2 block">
                      Стиль тату
                    </label>
                    <select
                      value={formData.style}
                      onChange={(e) => setFormData({ ...formData, style: e.target.value })}
                      className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-5 py-3.5 text-white font-inter text-sm focus:outline-none focus:border-accent/40 transition-colors appearance-none"
                    >
                      <option value="" className="bg-dark">Выберите стиль</option>
                      <option value="blackwork" className="bg-dark">Blackwork</option>
                      <option value="realism" className="bg-dark">Реализм</option>
                      <option value="fineline" className="bg-dark">Fine Line</option>
                      <option value="geometric" className="bg-dark">Геометрия</option>
                      <option value="watercolor" className="bg-dark">Watercolor</option>
                      <option value="other" className="bg-dark">Другое</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-inter text-white/30 tracking-widest uppercase mb-2 block">
                      Опишите идею
                    </label>
                    <textarea
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-5 py-3.5 text-white font-inter text-sm focus:outline-none focus:border-accent/40 transition-colors resize-none placeholder:text-white/20"
                      placeholder="Расскажите о вашей задумке..."
                    />
                  </div>

                  <motion.button
                    type="submit"
                    className="glass-btn w-full py-4 text-accent font-inter font-medium tracking-widest uppercase text-sm cursor-hover"
                    whileTap={{ scale: 0.98 }}
                  >
                    <span className="relative z-10">Отправить заявку</span>
                  </motion.button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
