import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";

export interface Application {
  id: string;
  name: string;
  phone: string;
  style: string;
  message: string;
  createdAt: string;
}

interface ApplicationsContextType {
  applications: Application[];
  addApplication: (app: Omit<Application, "id" | "createdAt">) => void;
  removeApplication: (id: string) => void;
}

const ApplicationsContext = createContext<ApplicationsContextType | null>(null);

const STORAGE_KEY = "xsink_applications";

function loadFromStorage(): Application[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

function saveToStorage(apps: Application[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(apps));
}

export function ApplicationsProvider({ children }: { children: ReactNode }) {
  const [applications, setApplications] = useState<Application[]>(loadFromStorage);

  // Sync across tabs / components via storage event
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) {
        setApplications(loadFromStorage());
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  // Also poll localStorage every second for same-tab updates
  useEffect(() => {
    const interval = setInterval(() => {
      const stored = loadFromStorage();
      setApplications((prev) => {
        if (JSON.stringify(prev) !== JSON.stringify(stored)) return stored;
        return prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const addApplication = useCallback((app: Omit<Application, "id" | "createdAt">) => {
    const newApp: Application = {
      ...app,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    setApplications((prev) => {
      const next = [newApp, ...prev];
      saveToStorage(next);
      return next;
    });
  }, []);

  const removeApplication = useCallback((id: string) => {
    setApplications((prev) => {
      const next = prev.filter((a) => a.id !== id);
      saveToStorage(next);
      return next;
    });
  }, []);

  return (
    <ApplicationsContext.Provider value={{ applications, addApplication, removeApplication }}>
      {children}
    </ApplicationsContext.Provider>
  );
}

export function useApplications() {
  const ctx = useContext(ApplicationsContext);
  if (!ctx) throw new Error("useApplications must be used within ApplicationsProvider");
  return ctx;
}
